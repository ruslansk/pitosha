pysqlcipher
===========

this library is an experimental fork of pysqlite,
and is statically linked against sqlcipher.

Original code (c) 2004-2007 Gerhard Häring
SQLCipher (c) 2013 Kali Kaneko

It uses a sqlcipher amalgamation, see https://www.sqlite.org/amalgamation.html

